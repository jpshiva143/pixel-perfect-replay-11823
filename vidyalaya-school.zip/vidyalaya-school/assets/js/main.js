'use strict';
(() => {
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.navbar-nav .nav-link').forEach(link => {
    if (link.getAttribute('href') === currentPage) {
      link.classList.add('active');
      link.setAttribute('aria-current', 'page');
    }
  });
  const year = document.getElementById('year');
  if (year) year.textContent = String(new Date().getFullYear());
  const header = document.querySelector('.site-header');
  const backTop = document.querySelector('.back-top');
  const updateScroll = () => {
    header?.classList.toggle('scrolled', window.scrollY > 20);
    backTop?.classList.toggle('visible', window.scrollY > 450);
  };
  window.addEventListener('scroll', updateScroll, { passive: true });
  updateScroll();
  backTop?.addEventListener('click', () => window.scrollTo({ top: 0, behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' }));
  if ('IntersectionObserver' in window) {
    document.documentElement.classList.add('js-ready');
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) { entry.target.classList.add('in-view'); observer.unobserve(entry.target); }
      });
    }, { threshold: 0.08 });
    document.querySelectorAll('.reveal').forEach(element => observer.observe(element));
  }
  // Bootstrap CDN components have a small accessible fallback for offline use.
  if (!window.bootstrap) {
    document.querySelector('.navbar-toggler')?.addEventListener('click', event => {
      const button = event.currentTarget;
      const target = document.querySelector(button.dataset.bsTarget);
      const expanded = target.classList.toggle('show');
      button.setAttribute('aria-expanded', String(expanded));
    });
    document.querySelectorAll('.accordion-button').forEach(button => button.addEventListener('click', () => {
      const target = document.querySelector(button.dataset.bsTarget);
      const open = !target.classList.contains('show');
      document.querySelectorAll('.accordion-collapse').forEach(panel => panel.classList.remove('show'));
      document.querySelectorAll('.accordion-button').forEach(other => { other.classList.add('collapsed'); other.setAttribute('aria-expanded', 'false'); });
      target.classList.toggle('show', open);
      button.classList.toggle('collapsed', !open);
      button.setAttribute('aria-expanded', String(open));
    }));
  }
  const dialog = document.querySelector('.lightbox');
  if (!dialog) return;
  const items = [...document.querySelectorAll('[data-gallery-index]')];
  const image = dialog.querySelector('img');
  const caption = dialog.querySelector('figcaption');
  let index = 0;
  let trigger = null;
  const display = next => {
    index = (next + items.length) % items.length;
    image.src = items[index].dataset.src;
    image.alt = items[index].querySelector('img').alt;
    caption.textContent = `${items[index].dataset.caption} — ${index + 1} / ${items.length}`;
  };
  items.forEach((item, position) => item.addEventListener('click', () => {
    trigger = item;
    display(position);
    dialog.showModal();
    document.body.style.overflow = 'hidden';
    dialog.querySelector('.lightbox-close').focus();
  }));
  dialog.querySelector('.lightbox-close').addEventListener('click', () => dialog.close());
  dialog.querySelector('.lightbox-prev').addEventListener('click', () => display(index - 1));
  dialog.querySelector('.lightbox-next').addEventListener('click', () => display(index + 1));
  dialog.addEventListener('keydown', event => {
    if (event.key === 'ArrowRight') { event.preventDefault(); display(index + 1); }
    if (event.key === 'ArrowLeft') { event.preventDefault(); display(index - 1); }
  });
  dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
  dialog.addEventListener('close', () => { document.body.style.overflow = ''; trigger?.focus(); });
})();
